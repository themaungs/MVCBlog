﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace MyBlogSite.Domain.Migrations.SeedData
{
    public static class StringExtensions
    {
        public static StreamReader ReadAsStream(this string input)
        {
            var stm = new MemoryStream(input.Length);
            stm.Write(System.Text.Encoding.UTF8.GetBytes(input), 0, input.Length);
            stm.Position = 0;

            return new StreamReader(stm);
        }
    }
}